#pragma once

#include <Windows.h>
#include <cstdint>
#include <locale>
#include <intrin.h>

namespace Containers
{
};